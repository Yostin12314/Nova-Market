document.addEventListener('DOMContentLoaded',async()=>{
 const products=document.querySelector('#products'),search=document.querySelector('#search');
 let type='';
 async function load(){products.innerHTML='<p class="muted">Cargando...</p>';try{
  const params=new URLSearchParams();if(search.value)params.set('q',search.value);if(type)params.set('type',type);
  const {items}=await api('/products?'+params);
  products.innerHTML=items.length?items.map(p=>`<a class="card" href="/product.html?id=${p.id}">${p.image?`<img src="${escapeHTML(p.image)}" alt="">`:'<div style="height:170px;display:grid;place-items:center;font-size:45px;background:#202b3b">✦</div>'}<div class="cardbody"><small>${escapeHTML(p.type==='digital'?'DIGITAL':'FÍSICO')} · ${escapeHTML(p.category)}</small><h3>${escapeHTML(p.title)}</h3><p>${escapeHTML(p.seller_name)}</p><div class="price">${money(p.price,p.currency)}</div></div></a>`).join(''):'<p class="muted">Todavía no hay publicaciones. ¡Sé el primero en vender!</p>';
 }catch(e){products.innerHTML=`<p class="muted">${escapeHTML(e.message)}. Comprueba que el servidor esté iniciado.</p>`}}
 let timer;search.addEventListener('input',()=>{clearTimeout(timer);timer=setTimeout(load,250)});
 document.querySelectorAll('[data-filter]').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('[data-filter]').forEach(x=>x.classList.remove('active'));b.classList.add('active');type=b.dataset.filter;load()}));
 if(localStorage.getItem('nova_token')){document.querySelector('#accountLink').textContent='Mi panel';document.querySelector('#accountLink').href='/dashboard.html'}
 load();
});
