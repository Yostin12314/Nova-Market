const API='/api';
const getToken=()=>localStorage.getItem('nova_token');
async function api(path,options={}) {
 const headers={...(options.headers||{})};
 if(getToken()) headers.Authorization='Bearer '+getToken();
 if(options.body && !(options.body instanceof FormData)) headers['Content-Type']='application/json';
 const response=await fetch(API+path,{...options,headers});
 const data=await response.json().catch(()=>({error:'Respuesta no válida del servidor.'}));
 if(!response.ok) throw new Error(data.error||'Ocurrió un error.');
 return data;
}
function money(value,currency='CAD'){return new Intl.NumberFormat('es-CA',{style:'currency',currency}).format(value)}
function escapeHTML(value=''){return String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
