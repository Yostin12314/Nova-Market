document.addEventListener('DOMContentLoaded',()=>{
 const form=document.querySelector('#loginForm')||document.querySelector('#registerForm');if(!form)return;
 form.addEventListener('submit',async e=>{e.preventDefault();const message=document.querySelector('#message');message.textContent='Procesando...';
 const values=Object.fromEntries(new FormData(form).entries());try{const endpoint=form.id==='loginForm'?'/auth/login':'/auth/register';const data=await api(endpoint,{method:'POST',body:JSON.stringify(values)});localStorage.setItem('nova_token',data.token);localStorage.setItem('nova_user',JSON.stringify(data.user));location.href='/dashboard.html'}catch(err){message.textContent=err.message}});
});
