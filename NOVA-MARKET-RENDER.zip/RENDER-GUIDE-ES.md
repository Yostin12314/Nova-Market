# Publicar NOVA MARKET en Render

Este proyecto se despliega como un **Web Service de Node.js**. La configuración `render.yaml` crea el servicio con un disco persistente de 1 GB para conservar la base SQLite y las imágenes subidas.

## Antes de publicar

- Necesitas una cuenta de GitHub y una cuenta de Render.
- Este proyecto usa un disco persistente de Render (`plan: starter`). Render indica que los discos persistentes requieren un servicio de pago; el plan Free no conserva archivos entre reinicios/despliegues.
- El disco guarda SQLite y los archivos de imagen en `/var/data`.

## Pasos

1. Descarga y descomprime `NOVA-MARKET-RENDER.zip`.
2. En GitHub, crea un repositorio nuevo llamado `nova-market`.
3. Sube **el contenido de esta carpeta** al nivel principal del repositorio. Debes ver `package.json`, `server.js` y `render.yaml` directamente en la raíz, no dentro de otra carpeta.
4. Entra en https://dashboard.render.com/ e inicia sesión.
5. Selecciona **New +** → **Blueprint**.
6. Conecta GitHub y selecciona el repositorio `nova-market`.
7. Render detectará `render.yaml`. Revisa el servicio `nova-market` y confirma la creación.
8. Espera a que termine el despliegue. Render mostrará una dirección similar a `https://nova-market.onrender.com`.

## Variables y persistencia

`render.yaml` genera automáticamente `JWT_SECRET`. No compartas ese valor. El disco persistente se monta en `/var/data`; la base de datos y las imágenes se guardan allí.

## Importante

- No selecciones el plan Free si quieres conservar registros, productos e imágenes: los discos persistentes requieren un servicio de pago.
- Esta aplicación es una base de marketplace, no un sistema de pagos listo para procesar dinero real. Antes de abrir ventas, revisa seguridad, moderación, privacidad, términos y proveedor de pagos.
- El repositorio debe tener estos archivos en la raíz para que Render detecte el Blueprint.
