# Configuración

Las variables de entorno se leen desde `.env` en la raíz. Copia `.env.example` a `.env` y genera un `JWT_SECRET` largo y aleatorio. No subas `.env` al repositorio.
