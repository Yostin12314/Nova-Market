const multer = require('multer');
const path = require('path');
const crypto = require('crypto');
const fs = require('fs');
const dir = path.resolve(process.env.UPLOADS_DIR || path.join(__dirname, '..', '..', 'uploads'));
fs.mkdirSync(dir, {recursive:true});
const allowed = new Set(['image/jpeg','image/png','image/webp','image/gif']);
const storage = multer.diskStorage({
  destination: (req,file,cb) => cb(null,dir),
  filename: (req,file,cb) => cb(null, crypto.randomBytes(16).toString('hex') + path.extname(file.originalname).toLowerCase())
});
const upload = multer({
  storage,
  limits:{fileSize:(Number(process.env.MAX_UPLOAD_MB)||5)*1024*1024},
  fileFilter:(req,file,cb)=>allowed.has(file.mimetype)?cb(null,true):cb(Object.assign(new Error('Formato de imagen no permitido.'),{status:400}))
});
module.exports = upload;
