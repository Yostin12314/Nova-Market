const router = require('express').Router();
const {getDb}=require('../database/db');
const {requireAuth}=require('../middleware/auth');
const upload=require('../middleware/upload');
const publicFields=`p.id,p.title,p.description,p.type,p.category,p.price,p.currency,p.image,p.status,p.created_at,u.id AS seller_id,u.name AS seller_name`;
router.get('/',(req,res)=>{
  const {q='',category='',type='',page='1'}=req.query;
  const limit=24, offset=(Math.max(1,Number(page)||1)-1)*limit;
  let sql=`SELECT ${publicFields} FROM products p JOIN users u ON u.id=p.user_id WHERE p.status='active'`;
  const args=[];
  if(q){sql+=' AND (p.title LIKE ? OR p.description LIKE ?)';args.push(`%${q}%`,`%${q}%`)}
  if(category){sql+=' AND p.category=?';args.push(category)}
  if(type){sql+=' AND p.type=?';args.push(type)}
  const items=getDb().prepare(sql+' ORDER BY p.created_at DESC LIMIT ? OFFSET ?').all(...args,limit,offset);
  res.json({items,page:Number(page)||1});
});
router.get('/:id',(req,res)=>{
 const item=getDb().prepare(`SELECT ${publicFields} FROM products p JOIN users u ON u.id=p.user_id WHERE p.id=? AND p.status='active'`).get(req.params.id);
 if(!item)return res.status(404).json({error:'Producto no encontrado.'});res.json({item});
});
router.post('/',requireAuth,upload.single('image'),(req,res)=>{
 const {title,description,type,category,price,currency='CAD'}=req.body;
 if(!title||!description||!['physical','digital'].includes(type)||!category||!Number.isFinite(Number(price))||Number(price)<0)
   return res.status(400).json({error:'Revisa los campos obligatorios.'});
 const image=req.file?`/uploads/${req.file.filename}`:'';
 const result=getDb().prepare('INSERT INTO products(user_id,title,description,type,category,price,currency,image) VALUES(?,?,?,?,?,?,?,?)')
  .run(req.user.id,title.trim(),description.trim(),type,category,Number(price),currency,image);
 res.status(201).json({id:result.lastInsertRowid,message:'Publicación creada.'});
});
router.delete('/:id',requireAuth,(req,res)=>{
 const d=getDb(), item=d.prepare('SELECT user_id FROM products WHERE id=?').get(req.params.id);
 if(!item)return res.status(404).json({error:'Producto no encontrado.'});
 if(item.user_id!==req.user.id && req.user.role!=='admin')return res.status(403).json({error:'No puedes eliminar esta publicación.'});
 d.prepare('DELETE FROM products WHERE id=?').run(req.params.id);res.json({message:'Publicación eliminada.'});
});
module.exports=router;
