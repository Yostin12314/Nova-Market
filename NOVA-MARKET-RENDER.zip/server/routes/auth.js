const router = require('express').Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { getDb } = require('../database/db');
const { requireAuth } = require('../middleware/auth');

router.post('/register', (req,res) => {
  const {name,email,password} = req.body || {};
  if (!name || name.trim().length < 2 || !/^\S+@\S+\.\S+$/.test(email || '') || (password || '').length < 8)
    return res.status(400).json({error:'Indica nombre, correo válido y contraseña de al menos 8 caracteres.'});
  const d=getDb(), normalized=email.trim().toLowerCase();
  if(d.prepare('SELECT id FROM users WHERE email=?').get(normalized)) return res.status(409).json({error:'Ese correo ya está registrado.'});
  const hash=bcrypt.hashSync(password,12);
  const result=d.prepare('INSERT INTO users(name,email,password_hash) VALUES(?,?,?)').run(name.trim(),normalized,hash);
  const user=d.prepare('SELECT id,name,email,role,bio FROM users WHERE id=?').get(result.lastInsertRowid);
  const token=jwt.sign({id:user.id,email:user.email,role:user.role},process.env.JWT_SECRET,{expiresIn:'7d'});
  res.status(201).json({token,user});
});
router.post('/login', (req,res) => {
  const {email,password}=req.body||{};
  const user=getDb().prepare('SELECT * FROM users WHERE email=?').get((email||'').trim().toLowerCase());
  if(!user || !bcrypt.compareSync(password||'',user.password_hash)) return res.status(401).json({error:'Correo o contraseña incorrectos.'});
  const token=jwt.sign({id:user.id,email:user.email,role:user.role},process.env.JWT_SECRET,{expiresIn:'7d'});
  res.json({token,user:{id:user.id,name:user.name,email:user.email,role:user.role,bio:user.bio}});
});
router.get('/me',requireAuth,(req,res)=>{
  const user=getDb().prepare('SELECT id,name,email,role,bio,created_at FROM users WHERE id=?').get(req.user.id);
  if(!user)return res.status(404).json({error:'Usuario no encontrado.'});
  res.json({user});
});
module.exports=router;
