const router=require('express').Router();
const {getDb}=require('../database/db');
const {requireAuth,requireAdmin}=require('../middleware/auth');
router.use(requireAuth,requireAdmin);
router.get('/overview',(req,res)=>{
 const d=getDb();
 res.json({
  users:d.prepare('SELECT COUNT(*) AS total FROM users').get().total,
  products:d.prepare('SELECT COUNT(*) AS total FROM products').get().total,
  activeProducts:d.prepare("SELECT COUNT(*) AS total FROM products WHERE status='active'").get().total
 });
});
router.patch('/products/:id/status',(req,res)=>{
 const status=req.body.status;
 if(!['active','hidden'].includes(status))return res.status(400).json({error:'Estado no válido.'});
 const result=getDb().prepare('UPDATE products SET status=? WHERE id=?').run(status,req.params.id);
 if(!result.changes)return res.status(404).json({error:'Producto no encontrado.'});
 res.json({message:'Estado actualizado.'});
});
module.exports=router;
