const router=require('express').Router();
const {getDb}=require('../database/db');
const {requireAuth}=require('../middleware/auth');
router.get('/:id',(req,res)=>{
 const user=getDb().prepare('SELECT id,name,bio,created_at FROM users WHERE id=?').get(req.params.id);
 if(!user)return res.status(404).json({error:'Vendedor no encontrado.'});
 const products=getDb().prepare("SELECT id,title,price,currency,image,type,category FROM products WHERE user_id=? AND status='active' ORDER BY created_at DESC").all(req.params.id);
 res.json({user,products});
});
router.patch('/me',requireAuth,(req,res)=>{
 const name=(req.body.name||'').trim(), bio=(req.body.bio||'').trim();
 if(name.length<2||name.length>60||bio.length>300)return res.status(400).json({error:'Revisa el nombre o la biografía.'});
 getDb().prepare('UPDATE users SET name=?,bio=? WHERE id=?').run(name,bio,req.user.id);
 res.json({message:'Perfil actualizado.'});
});
module.exports=router;
