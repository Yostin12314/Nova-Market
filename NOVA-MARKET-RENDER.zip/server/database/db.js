const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');
let db;
function getDb() {
  if (!db) {
    const filename = process.env.DATABASE_FILE || './server/database/nova-market.sqlite';
    const absoluteFilename = path.resolve(filename);
    fs.mkdirSync(path.dirname(absoluteFilename), { recursive: true });
    db = new Database(absoluteFilename);
    db.pragma('journal_mode = WAL');
    db.pragma('foreign_keys = ON');
  }
  return db;
}
function initDatabase() {
  const d = getDb();
  d.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'user',
      bio TEXT DEFAULT '',
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS products (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      title TEXT NOT NULL,
      description TEXT NOT NULL,
      type TEXT NOT NULL CHECK(type IN ('physical','digital')),
      category TEXT NOT NULL,
      price REAL NOT NULL CHECK(price >= 0),
      currency TEXT NOT NULL DEFAULT 'CAD',
      image TEXT DEFAULT '',
      status TEXT NOT NULL DEFAULT 'active',
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE INDEX IF NOT EXISTS idx_products_created ON products(created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_products_category ON products(category);
    CREATE INDEX IF NOT EXISTS idx_products_user ON products(user_id);
  `);
}
module.exports = { getDb, initDatabase };
