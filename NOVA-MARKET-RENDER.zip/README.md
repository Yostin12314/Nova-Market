# NOVA MARKET

Marketplace web para anuncios de artículos físicos y digitales. Incluye interfaz adaptable, API REST, registro e inicio de sesión, publicaciones, perfiles públicos y endpoints de administración.

## Requisitos
- Node.js 20 o superior
- npm

## Instalación local
1. Descomprime el proyecto.
2. Abre una terminal en la carpeta `NOVA-MARKET`.
3. Instala dependencias: `npm install`
4. Copia `.env.example` a `.env`.
5. Cambia `JWT_SECRET` por una clave aleatoria larga.
6. Inicia: `npm run dev` o `npm start`
7. Abre `http://localhost:3000`.

## Estructura
- `public/`: páginas, estilos, JavaScript e imágenes del frontend.
- `server/routes/`: endpoints de autenticación, productos, usuarios y administración.
- `server/database/`: inicialización SQLite.
- `server/middleware/`: autenticación y carga de imágenes.
- `uploads/`: imágenes cargadas por vendedores.
- `server.js`: punto de entrada de Express.

## Crear administrador
Por seguridad, el registro público siempre crea cuentas normales. Para promover una cuenta, inicia la app una vez y ejecuta una actualización directa en la base de datos con una herramienta SQLite de confianza:

```sql
UPDATE users SET role = 'admin' WHERE email = 'correo-del-propietario@ejemplo.com';
```

No publiques el panel de administración sin proteger también el entorno y las credenciales del propietario.

## Importante antes de producción
Este repositorio es una base funcional de desarrollo, no una plataforma de comercio electrónico lista para manejar dinero real. Antes de abrir al público:
- Configura HTTPS, dominio, copias de seguridad y secretos seguros.
- Usa un servicio de almacenamiento de imágenes persistente y escaneo de archivos.
- Añade verificación de correo, recuperación de contraseña, cierre/revocación de sesiones y protección CSRF si usas cookies.
- Añade moderación, reportes, políticas de contenido, privacidad y términos.
- Integra un proveedor de pagos autorizado y webhooks verificados; no almacenes datos de tarjetas.
- Configura límites, monitoreo, logs, pruebas automatizadas y revisión de seguridad.
- La base SQLite es apropiada para comenzar; evalúa PostgreSQL y almacenamiento externo al escalar.

## API principal
- `POST /api/auth/register`
- `POST /api/auth/login`
- `GET /api/auth/me`
- `GET /api/products`
- `GET /api/products/:id`
- `POST /api/products` (requiere sesión; multipart/form-data)
- `DELETE /api/products/:id` (propietario o admin)
- `GET /api/users/:id`
- `PATCH /api/users/me`
- `GET /api/admin/overview` (admin)
- `PATCH /api/admin/products/:id/status` (admin)
